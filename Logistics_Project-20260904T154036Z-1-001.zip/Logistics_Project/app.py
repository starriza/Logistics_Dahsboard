import streamlit as st
import pandas as pd

df = pd.read_csv("Logistics_dataset.csv", encoding='latin1')
df.columns = df.columns.str.strip()

df = df[['Country', 'Shipment Mode', 
         'Scheduled Delivery Date', 
         'Delivered to Client Date']]

df.dropna(inplace=True)

df['Scheduled Delivery Date'] = pd.to_datetime(df['Scheduled Delivery Date'])
df['Delivered to Client Date'] = pd.to_datetime(df['Delivered to Client Date'])

df['Delay'] = (df['Delivered to Client Date'] - df['Scheduled Delivery Date']).dt.days

st.title("🚚 Logistics Delay Dashboard")

st.write("Dataset Preview")
st.dataframe(df.head())

st.subheader("Average Delay")
st.write(df['Delay'].mean())

st.subheader("On-Time Delivery %")
st.write((df['Delay'] <= 0).mean() * 100)

st.bar_chart(df['Delay'])