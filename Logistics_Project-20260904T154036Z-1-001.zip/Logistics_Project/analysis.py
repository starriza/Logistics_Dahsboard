import pandas as pd

df = pd.read_csv("Logistics_dataset.csv", encoding='latin1')

# Fix column names (remove spaces issues)
df.columns = df.columns.str.strip()

# Select important columns only
df = df[['Country', 'Shipment Mode', 
         'Scheduled Delivery Date', 
         'Delivered to Client Date']]

# Remove missing values
df.dropna(inplace=True)

print(df.head())
# Convert to datetime
df['Scheduled Delivery Date'] = pd.to_datetime(df['Scheduled Delivery Date'])
df['Delivered to Client Date'] = pd.to_datetime(df['Delivered to Client Date'])

# Create Delay column
df['Delay'] = (df['Delivered to Client Date'] - df['Scheduled Delivery Date']).dt.days

print(df[['Delay']].head())
# KPIs
avg_delay = df['Delay'].mean()
on_time = (df['Delay'] <= 0).mean() * 100

print("Average Delay:", avg_delay)
print("On-Time Delivery %:", on_time)
import matplotlib.pyplot as plt
import seaborn as sns

sns.histplot(df['Delay'])
plt.title("Delay Distribution")
plt.show()